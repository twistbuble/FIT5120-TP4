package com.example.uidemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
    private ConstraintLayout con_date;
    private int mYear,mMonth,mDay;
    private TextView tv_a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        Calendar ca = Calendar.getInstance();
        mYear = ca.get(Calendar.YEAR);
        mMonth = ca.get(Calendar.MONTH);
        mDay = ca.get(Calendar.DAY_OF_MONTH);
        tv_a = findViewById(R.id.tv_a);
        l1 = findViewById(R.id.lin_1);
        l2 = findViewById(R.id.lin_2);
        l3 = findViewById(R.id.lin_3);
        l4 = findViewById(R.id.lin_4);
        l5 = findViewById(R.id.lin_5);
        l6 = findViewById(R.id.lin_6);
        l7 = findViewById(R.id.lin_7);
        l8 = findViewById(R.id.lin_8);
        l9 = findViewById(R.id.lin_9);
        l10 = findViewById(R.id.lin_10);
        con_date = findViewById(R.id.con_date);
        l1.setOnClickListener(this);
        l2.setOnClickListener(this);
        l3.setOnClickListener(this);
        l4.setOnClickListener(this);
        l5.setOnClickListener(this);
        l6.setOnClickListener(this);
        l7.setOnClickListener(this);
        l8.setOnClickListener(this);
        l9.setOnClickListener(this);
        l10.setOnClickListener(this);
        con_date.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.lin_1:
                choose1(l1,l2,l3);
                break;
            case R.id.lin_2:
                choose1(l2,l3,l1);
                break;
            case R.id.lin_3:
                choose1(l3,l1,l2);
                break;
            case R.id.lin_4:
                choose1(l4,l5,l6);
                break;
            case R.id.lin_5:
                choose1(l5,l6,l4);
                break;
            case R.id.lin_6:
                choose1(l6,l4,l5);
                break;
            case R.id.lin_7:
                choose2(l7,l8);
                break;
            case R.id.lin_8:
                choose2(l8,l7);
                break;
            case R.id.lin_9:
                choose2(l9,l10);
                break;
            case R.id.lin_10:
                choose2(l10,l9);
                break;
            case R.id.con_date:
                DatePickerDialog d = new DatePickerDialog(MainActivity.this, AlertDialog.THEME_HOLO_DARK, onDateSetListener, mYear, mMonth, mDay);
                d.setButton(DialogInterface.BUTTON_POSITIVE, "cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                d.setButton(DialogInterface.BUTTON_NEGATIVE, "confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        int year = d.getDatePicker().getYear();
                        int month = d.getDatePicker().getMonth()+1;
                        int day = d.getDatePicker().getDayOfMonth();
                        String dateStr = year + "-" + month + "-" + day;

                        tv_a.setText(dateStr);
                    }
                });
                d.show();
                break;
        }
    }
    /**
     * 日期选择器对话框监听
     */
    private DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            String days;
            if (mMonth + 1 < 10) {
                if (mDay < 10) {
                    days = new StringBuffer().append(mYear).append("-").append("0").
                            append(mMonth + 1).append("-").append("0").append(mDay).toString();
                } else {
                    days = new StringBuffer().append(mYear).append("-").append("0").
                            append(mMonth + 1).append("-").append(mDay).toString();
                }

            } else {
                if (mDay < 10) {
                    days = new StringBuffer().append(mYear).append("-").
                            append(mMonth + 1).append("-").append("0").append(mDay).toString();
                } else {
                    days = new StringBuffer().append(mYear).append("-").
                            append(mMonth + 1).append("-").append(mDay).toString();
                }

            }
        }
    };
    private void choose1(LinearLayout ln1,LinearLayout ln2,LinearLayout ln3){
        ln1.setBackgroundResource(R.mipmap.on);
        ln2.setBackgroundResource(R.mipmap.un);
        ln3.setBackgroundResource(R.mipmap.un);
    }
    private void choose2(LinearLayout ln1,LinearLayout ln2){
        ln1.setBackgroundResource(R.mipmap.on);
        ln2.setBackgroundResource(R.mipmap.un);
    }
}