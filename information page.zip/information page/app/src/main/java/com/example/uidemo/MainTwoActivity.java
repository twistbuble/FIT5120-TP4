package com.example.uidemo;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @Author : kezhijie
 * @Email : 827112947@qq.com
 * @Date : on 2022-09-15 14:44.
 * @Description :描述
 */
public class MainTwoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
    }
}
