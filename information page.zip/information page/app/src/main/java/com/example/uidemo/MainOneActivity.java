package com.example.uidemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @Author : kezhijie
 * @Email : 827112947@qq.com
 * @Date : on 2022-09-15 14:44.
 * @Description :描述
 */
public class MainOneActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);
        findViewById(R.id.iv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainOneActivity.this,MainTwoActivity.class));
            }
        });
    }
}
