package com.example.uidemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private MAdapter adapter;
    private RecyclerView re;
    private TextView tv_edit;
    private AppCompatButton btn_add;
    private List<KidsBean> mList = new ArrayList<>();
    int status=1; //1 添加 2编辑

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        re = findViewById(R.id.re);
        tv_edit = findViewById(R.id.tv_edit);
        btn_add = findViewById(R.id.btn_add);
        adapter = new MAdapter(R.layout.adapter_item);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        re.setLayoutManager(lm);
        re.setAdapter(adapter);
        adapter.setNewData(mList);

        tv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (KidsBean k:mList){
                    k.setStatus(2);
                }
                adapter.notifyDataSetChanged();
                if (status==1){
                    btn_add.setBackgroundResource(R.drawable.btn_select2);
                    tv_edit.setVisibility(View.GONE);
                    btn_add.setText("Save Profile");
                    status=2;
                }
            }
        });
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (status==2){
                    for (KidsBean k:mList){
                        k.setStatus(1);
                    }
                    adapter.notifyDataSetChanged();
                    btn_add.setBackgroundResource(R.drawable.btn_select);
                    tv_edit.setVisibility(View.VISIBLE);
                    btn_add.setText("Add a kid");
                    status=1;
                    return;
                }
                adapter.setNewData(mList);
            }
        });
    }

    private class MAdapter extends BaseQuickAdapter<KidsBean, BaseViewHolder>{

        public MAdapter(int layoutResId) {
            super(layoutResId);
        }

        @Override
        protected void convert(@NonNull BaseViewHolder helper, KidsBean item) {
            if (item.getStatus()==2){
                helper.getView(R.id.lin_1).setVisibility(View.GONE);
                helper.getView(R.id.lin_3).setVisibility(View.VISIBLE);
            }else{
                helper.getView(R.id.lin_1).setVisibility(View.VISIBLE);
                helper.getView(R.id.lin_3).setVisibility(View.GONE);
            }
            helper.getView(R.id.iv_icon).setBackgroundResource(item.getIcon());
            helper.setText(R.id.tv_name,item.getName())
                    .setText(R.id.tv_age,item.getAge()+" years old");
            helper.getView(R.id.lin_3).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    remove(helper.getAdapterPosition());
                }
            });
        }
    }
}