package com.example.uidemo;

public class KidsBean {
   private int icon;
   private String name;
   private String age;
   private int status;

   public KidsBean(int icon, String name, String age) {
      this.icon = icon;
      this.name = name;
      this.age = age;
   }

   public KidsBean(int icon, String name, String age, int status) {
      this.icon = icon;
      this.name = name;
      this.age = age;
      this.status = status;
   }

   public int getStatus() {
      return status;
   }

   public void setStatus(int status) {
      this.status = status;
   }

   public int getIcon() {
      return icon;
   }

   public void setIcon(int icon) {
      this.icon = icon;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAge() {
      return age;
   }

   public void setAge(String age) {
      this.age = age;
   }
}
